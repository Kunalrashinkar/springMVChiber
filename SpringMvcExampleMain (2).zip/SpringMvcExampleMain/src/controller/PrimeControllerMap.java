package controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import model.PrimeModel;

@Controller
public class PrimeControllerMap {
	@RequestMapping("Primeload")
	
	public ModelAndView primeLoad(@ModelAttribute("SpringMvcExampleMain")PrimeModel pr,ModelMap model)
	{
		String res = "";
		int i;
		for(i=2;i<pr.getNum();i++)
		{
			if(pr.getNum()%i==0)
			{
				res = "Not Prime";
				break;
			}
		}
		if(pr.getNum()==i)
		{
			res = "Prime";
			
		}
		model.addAttribute("key", res);
		return new ModelAndView("primeview1","command", new PrimeModel());
	}

}
