 package controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class FactorialController {
	@RequestMapping("factorialpath")
	public String factorialLoad()
	{
		return "factorialview";
	}
	
	@RequestMapping("factoriallogic")
	public ModelAndView factorialLogic(HttpServletRequest request)
	{
		int num = Integer.parseInt(request.getParameter("txtnum"));
		int fact=1;
        for(int i=1;i<=num;i++)
        {
            fact=fact*i;
        }
		return new ModelAndView ("factorialview","fact",fact);
		
	}

}
