package controller;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import model.Admin;
import model.SIModel;
@Controller
public class LoginController 
{
@RequestMapping("login")
public ModelAndView loginDemo(@ModelAttribute("SpringMvcExampleMain")Admin s, ModelMap mp)
{
	if(s!=null)
	{
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session ses = sf.openSession();
		Query q = ses.createQuery("from Admin e where e.username=? and e.password=?");
		q.setString(0,s.getUsername());
		q.setString(1,s.getPassword());
		List lst = q.list();
		if(lst.size()>0)
		{
			return new ModelAndView("redirect:showemp.do");
		}
		else
		{
			mp.addAttribute("key","Invalid userid and password");
			return new ModelAndView("login","command",new Admin());
			
		}
	}
	mp.addAttribute("key","");
	return new ModelAndView("login","command",new Admin());
}
}
